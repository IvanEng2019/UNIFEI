const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const handlebars = require('express-handlebars');
const app = express();


app.engine("handlebars", handlebars({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');
app.use('/CSS', express.static('css'));
app.use('/JS', express.static('js'));



//Start server
app.listen(3000, function(req, res){
   console.log('servidor rodando');

});

app.get("/", function(req, res){
    //res.sendFile(__dirname + "/principal.html")
    res.render('index');
});

app.get("/contato", function(req, res){
    res.send("pagina de contato")

});
