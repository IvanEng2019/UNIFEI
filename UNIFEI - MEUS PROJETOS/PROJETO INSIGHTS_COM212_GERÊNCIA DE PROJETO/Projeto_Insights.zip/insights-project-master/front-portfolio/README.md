Para instalar as dependências do front:

npm install

Depois para rodar a aplicação:

npm start

OBS.: 
1) O front vai rodar na porta 5500. 
Caso seja preciso mudar, é só abrir em "package.json" e mudar o valor de "SET PORT".
Como na imagem: 

![alt text](https://i.imgur.com/87zDXPN.png)

2) Back-end está aqui: https://github.com/lucasblazzi/insights-project
