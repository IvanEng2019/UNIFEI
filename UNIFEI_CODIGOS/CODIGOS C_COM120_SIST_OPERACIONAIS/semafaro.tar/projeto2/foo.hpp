#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#define MY_KEY 11111
#define MY_FILE "file_for_semaphore"

