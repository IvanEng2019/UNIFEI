#include "foo.hpp" // meio sem criatividade eu! não acha? foo.hpp 
using namespace std;

int myfuction();

char *shared_memory;
int main()
{
  int shmid=shmget(MY_KEY,0,IPC_CREAT); //colocamos a mesma chave do gerenciador aqui mais sem a flag IPC_EXCL a função não vai criar outro segmento se esse ja 
  //existir 
  if(shmid<0)
    {
      cerr<<"\nFalhou em shmid"<<endl;
      return -1;
    }
  shared_memory=(char *)shmat(shmid,0,0);// pointeiro para o segmento
  if(shared_memory<0)
    {
      cerr<<"\nFalhou em shmat"<<endl;     
 return -1;
    }

  myfuction();




  return 0;
}



int myfuction(){
  sem_t *SEM=sem_open(MY_FILE,O_CREAT,0,1); //abri o semaforo ja existente

  if(SEM==SEM_FAILED)
    {
      cerr<<"\nFalhou em sem_open"<<endl;
      return -1;
    }
  
  if(( sem_unlink(MY_FILE))<0) //mesmo caso descrito no código do gerenciador
    {
      cerr<<"\nFalhou em sem_unlink"<<endl;
      return -1;
    }




////////////////ITER COMUNICATION AREA!/////////////////// 

 string line;
 while(line!="exit") //só ira sair se voce digitar exit
   {
     cout<<"\nEscreva algo: ";
     getline(cin,line);
     sem_wait(SEM);
     strcpy(shared_memory,line.c_str());
     sem_post(SEM);
     
     cout<<"\nVoce escreveu "<<shared_memory<<endl;
   }

///////////////END OF INTER COMUNICATION AREA!/////////////








     return 0;



}
