
import java.util.ArrayList;
import javax.swing.JPanel;

public class ConsultaTurma extends JPanel {

    public ConsultaTurma(ArrayList listaDisciplina, ArrayList listaTurma) {
    }

}
