
package testaveiculo;

public class TestaVeiculo {

    public static void main(String[] args) {
        Motocicleta m = new Motocicleta("Yamaha", "branca", false, "speed");
        m.ligaMotor();
        m.mostraAtributos();
        Carro c = new Carro("Chevrolet", "prata", false, false);
        c.enchePortaMalas();
        c.ligaMotor();
        c.mostraAtributos();
    }
    
}
