
package testaveiculo;

public class Motocicleta extends Veiculo {
    
    private String estilo;
    
    public Motocicleta(String marca, String cor, boolean motorLigado,
                                     String estilo) {
        super(marca, cor, motorLigado);
        this.estilo = estilo;
    }

    public void mostraAtributos() {
        System.out.println("Esta moto é uma " + marca + " " + cor);
        System.out.println("Seu estilo é " + estilo);
        if (motorLigado == true) {
            System.out.println("Seu motor está ligado!");
        } else {
            System.out.println("Seu motor está desligado!");
        }
    }
    
}
