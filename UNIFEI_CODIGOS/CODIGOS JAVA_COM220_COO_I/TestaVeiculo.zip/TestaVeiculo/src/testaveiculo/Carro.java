package testaveiculo;

public class Carro extends Veiculo {

    private boolean portaMalasCheio;

    public Carro(String marca, String cor, boolean motorLigado,
            boolean portaMalasCheio) {
        super(marca, cor, motorLigado);
        this.portaMalasCheio = portaMalasCheio;
    }

    public void enchePortaMalas() {
        if (portaMalasCheio == true) {
            System.out.println("Porta malas já está cheio");
        } else {
            portaMalasCheio = true;
            System.out.println("Porta malas cheio");
        }
    }

    public void esvaziaPortaMalas() {
        if (portaMalasCheio == false) {
            System.out.println("Porta malas já está vazio");
        } else {
            portaMalasCheio = false;
            System.out.println("Porta malas esvaziado");
        }
    }

    public void mostraAtributos() {
        System.out.println("Este carro é um " + marca + " " + cor);
        if (motorLigado == true) {
            System.out.println("Seu motor está ligado!");
        } else {
            System.out.println("Seu motor está desligado!");
        }
        if (portaMalasCheio == true) {
            System.out.println("Seu porta malas está cheio!");
        } else {
            System.out.println("Seu porta malas está vazio!");
        }        
    }

}
