package testaveiculo;

public class Veiculo {

    protected String marca;
    protected String cor;
    protected boolean motorLigado;

    public Veiculo(String marca, String cor, boolean motorLigado) {
        this.marca = marca;
        this.cor = cor;
        this.motorLigado = motorLigado;
    }

    public void ligaMotor() {
        if (motorLigado == true) {
            System.out.println("O motor já está ligado!");
        } else {
            motorLigado = true;
            System.out.println("Motor acaba de ser ligado!");
        }
    }

    public void desligaMotor() {
        if (motorLigado == false) {
            System.out.println("O motor já está desligado!");
        } else {
            motorLigado = false;
            System.out.println("Motor acaba de ser desligado!");
        }
    }    
    
}
